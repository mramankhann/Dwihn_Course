# S10 · Objective Decisions with Data: From Trend to Action

**Week 7 · Module 8, part 2 of 2 · Live session + Q&A · 60 minutes**

## Handbook module reading

Read [Module 8 - Objective Decisions with Data](/modules/module-08) before this session. The module page provides the topic introduction, four detailed learning points with examples, key takeaways, and a practical scenario. Use this session page for the live demonstration and timed practice.

## 60-minute session plan (Q&A included)

The schedule below totals 60 minutes, including a dedicated five-minute Q&A and close. Keep the practice synthetic and assign any additional reading or unfinished reflection outside the live hour.

| Minutes | Activity | Learner evidence |
|---|---|---|
| 0-5 | Welcome; state a decision question | Decision question |
| 5-20 | Teach predictions, uncertainty, and proportionate action | Limits recorded |
| 20-30 | Instructor facilitates a synthetic data meeting | Decision log modeled |
| 30-50 | Learners run a short evidence-to-action meeting | Owner and due date recorded |
| 50-55 | Check assumptions and follow-up evidence | One open question named |
| 55-60 | Q&A and next step | Questions answered or assigned |

## Why this matters

The purpose of data analysis is to improve a decision, then check whether the action worked. The proposal calls for predictive insights and a data-driven team meeting. Prediction can help prioritize questions, but it is uncertain and may reflect biased, incomplete, or changing data. A human owner must decide what intervention is appropriate and ensure people are treated fairly.

## Outcomes and preparation

Run a short evidence-based meeting, compare competing explanations, use a forecast as a scenario rather than a fact, and create an action with owner and evaluation measure. Bring the S9 KPI card and S7 board brief.

## Teach: the decision cycle

![Evidence-to-action decision cycle](/diagrams/decision-cycle.svg){.diagram}

1. **Frame the decision.** Example: “Should we investigate follow-up workflow in one ZIP now, and how?”
2. **Examine evidence.** Confirm measure, population, source, period, and comparison.
3. **Consider alternatives.** Data quality, case mix, capacity, transportation, scheduling, or other workflow changes may explain a difference.
4. **Choose a proportionate action.** A reversible audit or staff conversation may be appropriate before a large program change.
5. **Assign and measure.** Name an owner, date, expected observation, and stop/revise condition.

### Predictive insight with boundaries

Lumenore publicly describes forecasting and deeper analysis capabilities. In a DWIHN context, a forecast may suggest that a metric is likely to cross a threshold **if present patterns persist**. It is not certainty and should never become an automatic individual-level care decision. Ask what training data, horizon, error range, and changing conditions the forecast depends on. Prefer a human-reviewed workflow when the stakes are high. [Lumenore advanced analytics](https://lumenore.com/advancedanalytics/)

### A five-minute meeting script

| Minute | Chair asks | Output |
|---|---|---|
| 0–1 | “What decision are we making?” | One sentence, named owner |
| 1–2 | “What do we know, and from which source?” | Verified measure and period |
| 2–3 | “What else could explain it?” | At least two plausible alternatives |
| 3–4 | “What is the smallest useful next action?” | Action, owner, due date |
| 4–5 | “What result would change our mind?” | Follow-up measure and review date |

## Instructor demonstration

Show the synthetic ZIP 48205 change from 64.5% to 59.1%. Offer two explanations: a scheduling bottleneck and a late data feed. Facilitate the five-minute meeting and choose a low-risk first step: validate the feed and review appointment capacity with the responsible team. Record what evidence would justify a later intervention. Do not characterize a ZIP or population as “noncompliant” from this table.

## Practice · 20 minutes

Groups of four take roles: chair, data owner, workflow owner, and challenge voice. Run the meeting script using the [synthetic data](/resources/synthetic-data). Produce a **one-page decision brief** with:

- Decision question and accountable owner.
- Observed rate change with numerator, denominator, period, and source.
- Two alternative explanations and a check for each.
- Action, due date, and review metric.
- Privacy/fairness consideration and uncertainty statement.

Swap briefs. The reviewing group identifies one conclusion that outruns the evidence and one action that cannot be measured. Revise before submission.

### Knowledge check

Why should a forecast trigger review rather than automatically trigger a member-level action? What makes an action testable?

<details><summary>Check your reasoning</summary>

Forecasts are uncertain and can inherit data errors or bias; human staff must apply policy and professional judgment. A testable action names an owner, timeframe, expected measure, and condition for changing course.

</details>

## Takeaway and work product

Keep the decision brief for the [capstone](/projects/capstone). Next: [S11 · Governance & Incident Handling](/sessions/s11-governance).
