# S11 · AI Governance & Incident Handling

**Week 8 · Module 9 · Live session + Q&A · 60 minutes**

## Handbook module reading

Read [Module 9 - AI Governance & Incident Handling](/modules/module-09) before this session. The module page provides the topic introduction, four detailed learning points with examples, key takeaways, and a practical scenario. Use this session page for the live demonstration and timed practice.

## 60-minute session plan (Q&A included)

The schedule below totals 60 minutes, including a dedicated five-minute Q&A and close. Keep the practice synthetic and assign any additional reading or unfinished reflection outside the live hour.

| Minutes | Activity | Learner evidence |
|---|---|---|
| 0-5 | Welcome; recall the reporting route | Channel or policy gap named |
| 5-20 | Teach governance roles and incident recognition | Role map |
| 20-30 | Instructor models a factual incident report | Facts separated from assumptions |
| 30-50 | Tabletop: contain safely, preserve facts, report, cooperate | Completed response record |
| 50-55 | Debrief and knowledge check | First action explained |
| 55-60 | Q&A and next step | Unresolved owner recorded |

## Why this matters

Governance makes safe use repeatable: someone approves tools and data, monitors performance, handles exceptions, and learns from incidents. The proposal mentions an AI Governance Committee, a 24-hour response target, and a five-step process, but does not provide DWIHN's charter, contacts, or written procedure. This lesson teaches a **proposed practice framework** until those documents are supplied. Staff should report a suspected exposure **immediately through the current internal channel**; privacy and security officers determine formal deadlines and notifications. [HHS breach notification framework](https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html)

## Outcomes and preparation

Recognize a possible AI incident, carry out immediate safe actions, document facts without spreading sensitive data, and explain who owns investigation and notification. Read the [incident card](/resources/incident-card).

## Teach: who does what

| Role | Proposed responsibility to confirm with DWIHN |
|---|---|
| Staff member | Stop further use or sharing, preserve facts, report promptly, cooperate with instructions. |
| Manager | Help the staff member report, protect members and evidence, maintain a supportive culture, avoid independent legal conclusions. |
| Privacy / security response | Triage exposure, assess scope and risk, direct containment, preserve records, determine required notifications. |
| Tool and data owners | Check configuration, permissions, logs, model behavior, and corrective controls. |
| AI Governance Committee | Review patterns, approved use cases, risk controls, training changes, and closure evidence. |

The committee structure above is instructional. DWIHN must confirm its actual ownership and escalation map.

## Recognize an incident

Examples include entering PHI into an unapproved AI account; exporting a restricted dashboard to the wrong group; an AI-generated summary being saved as fact when it invents a critical event; a bot recommending an unsafe response; an unauthorized recording; or a permission change that exposes data. A **near miss** also deserves reporting under current policy, because it can reveal a broken control before harm occurs.

### Proposed five-step response

![Five-step incident response](/diagrams/incident-flow.svg){.diagram}

1. **Stop and contain.** Stop the activity, stop further sharing, and follow approved containment instructions. Do not attempt a risky cleanup or delete evidence on your own.
2. **Report.** Contact the current DWIHN incident channel or supervisor immediately with the known facts. The proposal's “within 24 hours” is a proposed internal target, **not** permission to wait.
3. **Preserve facts.** Record time, tool/account, data type, recipient/destination, actions already taken, and what remains uncertain. Use approved secure channels; do not copy the exposed data into a new message.
4. **Assess and remediate.** Authorized privacy/security and tool owners determine scope, obligations, containment, notifications, and technical or process changes.
5. **Learn and close.** Document root cause, owner, corrective action, due date, and a check that the fix works. Share sanitized lessons with staff.

HHS breach notification timelines depend on the type and facts of a breach. The internal staff action here is **prompt reporting**, not deciding whether an event meets a legal definition.

## Instructor demonstration

Present this **synthetic** event: a program analyst exports a ZIP chart that includes a small cell and accidentally shares the link with a broad Teams group. The analyst notices after two minutes. Walk through the five steps. Model a factual report: when, where, what type of data, who may have access, and what has been done. Avoid blame and avoid forwarding the chart again to “show” the problem.

## Practice · 20 minutes

In groups, run a tabletop. Assign staff, manager, privacy/security lead, and tool owner. At minute 1, the link is shared; at minute 5, someone outside the intended group opens it; at minute 10, the analyst wants to delete the post. Record each role's action and the facts needed. The instructor may add a complication: the chart source might contain identifiable information despite a missing name.

Deliver a one-page incident record with **timeline**, **known facts**, **unknowns**, **containment request**, **reporting route**, and **one preventive control**. Score the sequence, not the confidence of a legal conclusion.

### Knowledge check

1. Should staff wait up to 24 hours before reporting a possible exposure?
2. Who decides whether legal breach notification is required?
3. Why should staff avoid forwarding the exposed data as proof?

<details><summary>Check your reasoning</summary>

1. No; report promptly using current internal instructions.
2. Authorized privacy/security/legal decision makers apply the facts and law.
3. Forwarding may widen the exposure; report facts through the approved secure channel.

</details>

## Takeaway and work product

Keep the incident record and learn your current reporting channel before using live AI tools. Next: [S12 · Assessment & Certification](/sessions/s12-certification).
