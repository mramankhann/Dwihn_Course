# S12 · Assessment & Certification

**Week 9 · Module 10 · Assessment + Q&A + recognition · 60 minutes**

## Handbook module reading

Read [Module 10 - Knowledge Assessment & Certification](/modules/module-10) before this session. The module page provides the topic introduction, four detailed learning points with examples, key takeaways, and a practical scenario. Use this session page for the live demonstration and timed practice.

## Purpose

This session consolidates Modules 1–9 and checks whether staff can make safe, useful decisions without prompting from the trainer. The source proposal calls for an online 20-question assessment, live Q&A, and a DWIHN AI Readiness certificate. The website provides the [questions](/assessment/final) and [practical case](/projects/capstone); DWIHN must approve the formal delivery platform, pass rule, retake process, attendance requirement, and certificate issuer.

## Outcomes and preparation

Explain the safe-use routine, complete the knowledge assessment, demonstrate a practical data-to-decision workflow, and identify where to seek help after the course. Review your S4 artifact, S7 report, S8 call summary, S10 brief, and S11 incident record.

## 60-minute session plan (Q&A included)

The full assessment, practical case, Q&A, and close fit within the hour. If DWIHN requires a longer secure testing window or an accommodation, schedule the test separately and use the live hour for review, practical demonstration, and Q&A.

| Minutes | Activity | Evidence |
|---|---|---|
| 0-5 | Welcome; explain assessment conditions and access needs | Learners know the process |
| 5-10 | Rapid review of Classify, Confirm, Review | Verbal reasoning |
| 10-30 | Individual 20-question knowledge assessment | Answer sheet |
| 30-47 | Practical case: tool path, analytics interpretation, output review, incident first steps | Scored worksheet |
| 47-52 | Debrief and feedback on critical safety steps | Corrected reasoning |
| 52-57 | Dedicated Q&A; assign unresolved policy or tenant questions | Questions answered or routed |
| 57-60 | Close and explain approved certificate follow-up | Completion next step |

## Practical evaluation

The [capstone](/projects/capstone) combines classification, tool selection, Lumenore interpretation, communication review, and incident response. A good submission gives enough evidence that another reviewer can follow the decision. The instructor uses the rubric in that page and the private answer key in the source repository.

### Proposed pass rule

The course proposes **16/20 or higher** on the knowledge questions, plus all **critical safety steps** in the practical case: classify the data, confirm the authorized destination or stop, reject an unsupported AI claim, avoid disclosing a small cell, and report a possible exposure promptly. DWIHN may revise this standard. A missed critical step leads to feedback and a new practice case before a certificate is issued.

## After the course

Keep the [daily checklist](/resources/daily-checklist), [prompt builder](/resources/prompt-builder), [analytics review card](/resources/analytics-checklist), and [incident card](/resources/incident-card). Tool catalogs, policies, and product features change; check current versions during real work. Bring unresolved questions to your manager, privacy/security contact, data owner, or AI governance channel as applicable.
