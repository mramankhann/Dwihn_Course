import { defineConfig } from 'vitepress'

export default defineConfig({
  title: 'DWIHN AI Readiness',
  description: 'A practical, safety-first AI training course for DWIHN staff',
  lang: 'en-US',
  cleanUrls: true,
  lastUpdated: true,
  themeConfig: {
    logo: '/mark.svg',
    siteTitle: 'DWIHN AI Readiness',
    search: { provider: 'local' },
    nav: [
      { text: 'Start', link: '/course/overview' },
      { text: 'Modules', link: '/course/month-1' },
      { text: 'Sessions', link: '/course/roadmap' },
      { text: 'Job aids', link: '/resources/daily-checklist' },
      { text: 'Assessment', link: '/assessment/final' }
    ],
    sidebar: [
      {
        text: 'Start here',
        items: [
          { text: 'Course overview', link: '/course/overview' },
          { text: 'Nine-week roadmap', link: '/course/roadmap' },
          { text: 'Learner guide', link: '/course/learner-guide' },
          { text: 'Role pathways', link: '/course/role-pathways' }
        ]
      },
      {
        text: 'Month 1 · AI Foundations & Safe Usage',
        collapsed: false,
        items: [
          { text: 'Month 1 goals', link: '/course/month-1' },
          { text: 'M1 · What AI Is — and Isn\'t', link: '/modules/module-01' },
          { text: 'M2 · Approved Tools & HIPAA', link: '/modules/module-02' },
          { text: 'M3 · Data Classification', link: '/modules/module-03' },
          { text: 'M4 · Prompting Skills', link: '/modules/module-04' },
          { text: 'M5 · Daily DWIHN Work', link: '/modules/module-05' },
          { text: 'S1 · What AI Is — and Isn\'t', link: '/sessions/s01-what-ai-is' },
          { text: 'S2 · Tools, HIPAA & classification', link: '/sessions/s02-tools-and-data' },
          { text: 'S3 · Prompting skills', link: '/sessions/s03-prompting' },
          { text: 'S4 · Daily DWIHN work', link: '/sessions/s04-daily-work' }
        ]
      },
      {
        text: 'Month 2 · Advanced AI & Lumenore Mastery',
        collapsed: false,
        items: [
          { text: 'Month 2 goals', link: '/course/month-2' },
          { text: 'M6 · Lumenore Impact', link: '/modules/module-06' },
          { text: 'M7 · Genesys AI', link: '/modules/module-07' },
          { text: 'M8 · Objective Decisions', link: '/modules/module-08' },
          { text: 'M9 · Governance & Incidents', link: '/modules/module-09' },
          { text: 'M10 · Certification', link: '/modules/module-10' },
          { text: 'S5 · Lumenore Ask Me', link: '/sessions/s05-lumenore-ask-me' },
          { text: 'S6 · Dashboards & service gaps', link: '/sessions/s06-lumenore-dashboards' },
          { text: 'S7 · Alerts & board reports', link: '/sessions/s07-lumenore-alerts' },
          { text: 'S8 · Genesys AI', link: '/sessions/s08-genesys' },
          { text: 'S9 · Trustworthy measures', link: '/sessions/s09-objective-data' },
          { text: 'S10 · Data-driven decisions', link: '/sessions/s10-decisions' },
          { text: 'S11 · Governance & incidents', link: '/sessions/s11-governance' },
          { text: 'S12 · Assessment', link: '/sessions/s12-certification' }
        ]
      },
      {
        text: 'Practice & resources',
        items: [
          { text: 'Capstone case', link: '/projects/capstone' },
          { text: 'Final assessment', link: '/assessment/final' },
          { text: 'Daily AI checklist', link: '/resources/daily-checklist' },
          { text: 'Data classification card', link: '/resources/data-desk-card' },
          { text: 'Prompt builder', link: '/resources/prompt-builder' },
          { text: 'Analytics review card', link: '/resources/analytics-checklist' },
          { text: 'Synthetic practice data', link: '/resources/synthetic-data' },
          { text: 'Incident response card', link: '/resources/incident-card' },
          { text: 'Glossary', link: '/resources/glossary' },
          { text: 'Sources & verification', link: '/resources/references' }
        ]
      },
      {
        text: 'Course administration',
        items: [
          { text: 'Instructor guide', link: '/course/instructor-guide' },
          { text: 'Source-to-course map', link: '/course/source-map' }
        ]
      }
    ],
    outline: [2, 3],
    docFooter: { prev: 'Previous', next: 'Next' },
    footer: {
      message: 'Training content based on the DWIHN AI Training Handbook and 2026 Netlink / NetSeed proposal. Verify current DWIHN policy and tool configuration before live use.',
      copyright: 'DWIHN AI Readiness · Training edition'
    }
  }
})
