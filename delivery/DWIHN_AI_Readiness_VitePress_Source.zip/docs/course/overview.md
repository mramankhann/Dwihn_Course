# Course overview

## Purpose and audience

**DWIHN AI Readiness** prepares staff to use approved AI and analytics tools as accountable aids to their work. It is designed for care coordinators, program managers, access call center staff, administrators, compliance staff, and leaders. No coding or prior AI experience is required. Learners need a Teams connection, the course site, and (for product demonstrations) authorized access to a DWIHN-approved training environment.

The course uses the **DWIHN AI Training Handbook** for detailed teaching content and the Netlink / NetSeed proposal for the session schedule and program requirements. DWIHN's [Access Call Center](https://dwihn.org/programs-services/crisis-services/access-services) supports Wayne County residents with screening, linkage, referrals, and crisis collaboration; [quality improvement](https://dwihn.org/provider-resources/quality-improvement) includes care coordination and access measures. Those verified activities shape the examples. Every member, call, metric, and dashboard in practice cases is **invented for training**.

## At a glance

| Element | Plan |
|---|---|
| Duration | Nine weeks; 12 live sessions of 60 minutes |
| Structure | 10 modules in two learning phases called Month 1 and Month 2 in the proposal |
| Delivery | Microsoft Teams teaching, demonstration, guided practice, Q&A; this VitePress site supports preparation and review |
| Practice | Synthetic cases, prompt writing, analytics interpretation, call review, incident simulation |
| Milestones | S4 role workflow; S7 analytics report; S11 incident tabletop; S12 final assessment |
| Final evidence | 20 knowledge questions plus one practical decision case |

## Learn by month and module

The handbook defines **Month 1: AI Foundations & Safe Usage** ([Modules 1–5](/course/month-1)) and **Month 2: Advanced AI & Lumenore Mastery** ([Modules 6–10](/course/month-2)). Each module page has a topic introduction, four detailed learning points with DWIHN-oriented examples, key takeaways, a practical scenario, a knowledge check, and an action plan. The [12 session guides](/course/roadmap) add instructor demonstration and timed live practice.

Start with [Module 1](/modules/module-01). Read its four points, complete the exercise, then attend or review the linked live session. Continue in order through [Module 10](/modules/module-10).

::: info Schedule interpretation
The source schedule table runs from Week 1 through Week 9. Its summary says “eight weeks,” which conflicts with the table. This course follows the table and the requested Week 9 certification session. “Month 1” and “Month 2” name learning phases, not equal calendar months.
:::

## What you will be able to do

1. Explain where AI helps with drafting, summarization, analysis, and pattern finding, and where human judgment remains essential.
2. Check a task and its data against the **current** DWIHN Approved AI Tool Catalog before using an AI feature.
3. Apply the proposal's four data-tier labels in practice, and defer to DWIHN's official definitions for real records.
4. Write a five-part prompt: **Role, Task, Context, Format, Constraint**; then verify and edit the result.
5. Complete a role-specific draft, report, or analysis without treating AI output as an approved final product.
6. Ask Lumenore questions, inspect filters and definitions, interpret dashboards and alerts, and communicate a decision with uncertainty.
7. Review Genesys AI transcripts, summaries, knowledge suggestions, sentiment, and routing as available in the DWIHN tenant.
8. Recognize a possible AI incident, contain further exposure, and report it through the current internal channel.

## The learning rule

![Three checks: classify, confirm, review](/diagrams/safe-use.svg){.diagram}

**Classify → Confirm → Review** is repeated in every module. The purpose is to prevent a fast draft or attractive chart from outrunning permission, source quality, or professional judgment. If a check cannot be completed, pause and ask the designated DWIHN owner.

## Assessment and certificate

Short checks support learning in S1–S11. In S12, the instructor administers the [20-question assessment](/assessment/final) and a [practical case](/projects/capstone). The proposed readiness standard is **80% on the knowledge questions and every critical safety step on the practical rubric**. DWIHN must approve its final standard, attendance rule, retake method, and certificate issuer before certification is announced.

## What this course cannot establish

The proposal names Lumenore Impact, Genesys AI, Teams AI, and an approved tool catalog, but it does not include the live DWIHN catalog or product configuration. A product capability is not proof that a feature is enabled or permitted for a specific data tier. See [sources and verification](/resources/references) before teaching or using a live workflow.
