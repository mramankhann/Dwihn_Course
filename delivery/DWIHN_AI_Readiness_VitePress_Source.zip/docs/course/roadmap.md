# Nine-week roadmap

The schedule follows the proposal's visual session table: **S2 covers Modules 2 and 3; S3 covers Module 4; S4 covers Module 5**. Every session is **60 minutes total, including its dedicated Q&A**. Module reading and any unfinished reflection happen before or after the live hour.

| Week | Session | Module | Topic | Format | Learner evidence |
|---|---|---|---|---|---|
| 1 | [S1](/sessions/s01-what-ai-is) | 1 | What AI Is — and Isn't | Live + Q&A | Strengths-and-limits card |
| 2 | [S2](/sessions/s02-tools-and-data) | 2–3 | Approved Tools & HIPAA Safety; Data Classification in Practice | Live + Q&A | Tool-choice and classification case |
| 3 | [S3](/sessions/s03-prompting) | 4 | Prompting Skills for DWIHN Roles | Live + Q&A | Three safe prompts |
| 3 | [S4](/sessions/s04-daily-work) | 5 | AI in Your Daily DWIHN Work | Live + Q&A | Reviewed role artifact |
| 4 | [S5](/sessions/s05-lumenore-ask-me) | 6 | Lumenore Impact — Ask Me | Live demo + practice + Q&A | Question and validation log |
| 4–5 | [S6](/sessions/s06-lumenore-dashboards) | 6 | Lumenore Impact — dashboards and ZIP analysis | Live demo + practice + Q&A | Filtered view and interpretation |
| 5 | [S7](/sessions/s07-lumenore-alerts) | 6 | Lumenore Impact — alerts and board reports | Live demo + practice + Q&A | Alert design and report brief |
| 6 | [S8](/sessions/s08-genesys) | 7 | Genesys AI — Call Center | Live + Q&A | Reviewed call summary |
| 7 | [S9](/sessions/s09-objective-data) | 8 | Objective Decisions with Data — definitions and trends | Live + Q&A | KPI definition sheet |
| 7 | [S10](/sessions/s10-decisions) | 8 | Objective Decisions with Data — meeting and action | Live + Q&A | Decision brief |
| 8 | [S11](/sessions/s11-governance) | 9 | Governance & Incident Handling | Live + Q&A | Incident tabletop |
| 9 | [S12](/sessions/s12-certification) | 10 | Assessment & Certification | Assessment + Q&A + recognition | 20 questions and practical case |

## Learning progression

| Phase | Weeks | Goal | Milestone |
|---|---|---|---|
| [Month 1: Foundations](/course/month-1) | 1–3 | Safe decisions and useful prompts | A reviewed draft for one real role, using synthetic data |
| [Month 2: Applied AI](/course/month-2) | 4–9 | Analytics, call-center judgment, governance | A source-checked decision brief and incident response |

### Standard 60-minute session rhythm

| Minutes | Activity |
|---|---|
| 0-5 | Welcome, purpose, and retrieval question |
| 5-20 | Teach the session concepts using one work example |
| 20-30 | Instructor demonstration with synthetic material |
| 30-50 | Guided learner practice |
| 50-55 | Knowledge check and debrief |
| 55-60 | Open Q&A, unresolved-question capture, and next step |

S2 deliberately teaches two modules in one hour, so the instructor assigns the [data desk card](/resources/data-desk-card) as preparation and keeps the live case focused. S12 uses a different rhythm for review, testing, practical evaluation, and recognition.
