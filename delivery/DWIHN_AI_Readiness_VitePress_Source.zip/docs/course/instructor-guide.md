# Instructor guide

This guide supports delivery of the 12 one-hour Teams sessions. It is based on the proposal's delivery model; the DWIHN and Netlink owners must confirm operational details before invitations are sent.

The supplied DWIHN AI Training Handbook is the teaching source for the ten [module pages](/course/month-1). Assign the relevant module before class. In the live session, use the module's four points and practice case as the content spine; use the session page for timing, demonstration, and work-product instructions. S2 covers Modules 2 and 3, S5–S7 divide Module 6, and S9–S10 divide Module 8.

## Preparation checklist

| When | Instructor action |
|---|---|
| Before the program | Obtain the current Approved AI Tool Catalog, four-tier policy, HIPAA/privacy training requirements, incident contacts, product access matrix, and certificate rules. Replace provisional examples where policy differs. |
| Before S2 | Have the catalog open and identify an owner for disputed tool/data combinations. Do not describe a named service as PHI-approved without written confirmation. |
| Before S5–S7 | Verify the Lumenore tenant, dataset names, permissions, filters, dashboards, alert controls, export rules, and a synthetic or approved training dataset. |
| Before S8 | Verify the Genesys license and enabled transcription, summary, knowledge, sentiment, routing, and recording features; confirm privacy settings and quality review process. |
| Before S11 | Confirm reporting channel, immediate containment instructions, escalation roles, evidence handling, and any internal timing standard. |
| Before S12 | Approve assessment pass criteria, accommodations, retakes, attendance, certificate wording, and issuer. |

## Standard facilitation pattern

Every session is **60 minutes total, with five minutes reserved for Q&A and close**. The session pages include a run-of-show table whose segments add to exactly one hour. Assign the module reading before class so live teaching, practice, the knowledge check, and Q&A fit without extending the session. S2 covers two modules and uses a compressed teaching plan; the detailed module pages can be completed as prework or follow-up.

1. **Open.** State the decision and the learning outcome; invite a quick retrieval response.
2. **Explain.** Teach one or two ideas with a workplace example; use the module page for detail.
3. **Demonstrate.** Narrate safety and validation checks with synthetic material.
4. **Practice.** Ask every learner to produce a small work product; invite one learner to explain a different choice.
5. **Check and answer.** Use the knowledge check to correct a misconception, then reserve the final five minutes for Q&A and unresolved-question routing.

## Facilitation notes by session

| Session | Demonstration | Likely misconception to address |
|---|---|---|
| S1 | Compare a strong draft and a confident false claim | Fluent wording is not evidence. |
| S2 | Trace a synthetic member summary through classification and the live catalog | A product name alone is not approval. |
| S3 | Improve a vague prompt with five parts | Longer prompts are not automatically better. |
| S4 | Edit an AI-generated letter with a review log | A polished draft is not ready to send. |
| S5 | Ask a scoped KPI question, then inspect source and filters | A chart title does not define a measure. |
| S6 | Filter a dashboard by ZIP and compare denominator and small cells | A darker map color is not proof of a service gap. |
| S7 | Create a proposed alert and an annotated board report | Alerts require owners, thresholds, and response plans. |
| S8 | Correct a synthetic transcript/summary and choose escalation | Sentiment is a signal, not a diagnosis or triage decision. |
| S9 | Reconcile two apparently conflicting rates | Different denominators or date ranges can both be valid. |
| S10 | Chair a five-minute data decision meeting | Forecasts do not remove human accountability. |
| S11 | Run a five-step incident tabletop | The proposal's 24-hour target does not replace immediate internal reporting. |
| S12 | Administer knowledge and practical checks | Certificate criteria need DWIHN approval. |

## Records, accessibility, and support

- Obtain permission to record and follow DWIHN's retention and access rules. Keep real member data out of demonstration recordings.
- Provide captioning, readable materials, alt text, and a text alternative for each diagram. Permit written or spoken responses where assessment rules allow.
- The proposal plans a support Teams channel and recordings. The program owner confirms the channel, moderation, response target, and recording location.
- Use `instructor/assessment-key.md` from the source repository. It is intentionally outside the published VitePress site.

## Feedback and remediation

For each practice task, give feedback on **permission and data**, **factual verification**, **human judgment**, and **clarity**. A missed critical safety step triggers coaching and a new case before certification. Capture repeated catalog or tool-access questions for the governance owner; do not silently turn an instructor guess into policy.
