---
layout: home

hero:
  name: DWIHN AI Readiness
  text: Learn to use AI safely in real DWIHN work
  tagline: Twelve live sessions, ten modules, nine weeks. Practice with synthetic cases before using any approved workplace tool.
  actions:
    - theme: brand
      text: Start the course
      link: /course/overview
    - theme: alt
      text: View the roadmap
      link: /course/roadmap

features:
  - title: Safe foundations
    details: Understand AI's strengths and limits, approved tools, HIPAA boundaries, classification, and prompting.
  - title: Real role practice
    details: Work through care coordination, call center, program reporting, administration, compliance, and leadership cases.
  - title: Evidence to action
    details: Ask better data questions in Lumenore, review Genesys AI signals, and make accountable decisions.
  - title: Readiness assessment
    details: Complete checks during the course and finish with a 20-question assessment and practical case.
---

::: warning Before live use
This training site contains **synthetic examples**. The proposal does not provide DWIHN's current approved-tool catalog, exact data-tier policy, incident contacts, or tenant feature configuration. Follow current DWIHN policy and your authorized access for real work.
:::

The curriculum follows the DWIHN AI Training Handbook and Netlink / NetSeed 2026 proposal. Start with the [overview](/course/overview), then work through [Month 1 modules](/course/month-1) and [Month 2 modules](/course/month-2) alongside the [session roadmap](/course/roadmap). Instructors should review the [delivery guide](/course/instructor-guide) and [verification list](/resources/references) before teaching.
