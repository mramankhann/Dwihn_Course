import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Analytics review card","description":"","frontmatter":{},"headers":[],"relativePath":"resources/analytics-checklist.md","filePath":"resources/analytics-checklist.md","lastUpdated":null}');
const _sfc_main = { name: "resources/analytics-checklist.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 4)
  ])]);
}
const analyticsChecklist = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  analyticsChecklist as default
};
