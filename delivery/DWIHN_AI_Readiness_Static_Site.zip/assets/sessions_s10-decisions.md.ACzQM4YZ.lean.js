import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const _imports_0 = "/diagrams/decision-cycle.svg";
const __pageData = JSON.parse('{"title":"S10 · Objective Decisions with Data: From Trend to Action","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s10-decisions.md","filePath":"sessions/s10-decisions.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s10-decisions.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 29)
  ])]);
}
const s10Decisions = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s10Decisions as default
};
