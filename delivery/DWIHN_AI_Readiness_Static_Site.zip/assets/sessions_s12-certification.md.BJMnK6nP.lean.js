import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S12 · Assessment & Certification","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s12-certification.md","filePath":"sessions/s12-certification.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s12-certification.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 17)
  ])]);
}
const s12Certification = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s12Certification as default
};
