import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S2 · Approved Tools, HIPAA Safety & Data Classification","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s02-tools-and-data.md","filePath":"sessions/s02-tools-and-data.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s02-tools-and-data.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 33)
  ])]);
}
const s02ToolsAndData = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s02ToolsAndData as default
};
