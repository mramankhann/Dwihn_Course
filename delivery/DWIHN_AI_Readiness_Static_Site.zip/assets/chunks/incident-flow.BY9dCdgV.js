const _imports_0 = "/diagrams/incident-flow.svg";
export {
  _imports_0 as _
};
