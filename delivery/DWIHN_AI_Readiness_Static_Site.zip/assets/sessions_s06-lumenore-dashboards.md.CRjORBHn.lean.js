import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S6 · Lumenore Impact: Dashboards and Service-Gap Analysis","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s06-lumenore-dashboards.md","filePath":"sessions/s06-lumenore-dashboards.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s06-lumenore-dashboards.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 29)
  ])]);
}
const s06LumenoreDashboards = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s06LumenoreDashboards as default
};
