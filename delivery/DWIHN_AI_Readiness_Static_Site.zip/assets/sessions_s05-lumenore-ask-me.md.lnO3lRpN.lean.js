import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S5 · Lumenore Impact: Ask Me and Trustworthy Questions","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s05-lumenore-ask-me.md","filePath":"sessions/s05-lumenore-ask-me.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s05-lumenore-ask-me.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 29)
  ])]);
}
const s05LumenoreAskMe = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s05LumenoreAskMe as default
};
