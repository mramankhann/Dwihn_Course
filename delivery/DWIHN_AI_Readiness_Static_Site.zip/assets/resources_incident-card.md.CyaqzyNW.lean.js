import { _ as _imports_0 } from "./chunks/incident-flow.BY9dCdgV.js";
import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"AI incident response card","description":"","frontmatter":{},"headers":[],"relativePath":"resources/incident-card.md","filePath":"resources/incident-card.md","lastUpdated":null}');
const _sfc_main = { name: "resources/incident-card.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 7)
  ])]);
}
const incidentCard = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  incidentCard as default
};
