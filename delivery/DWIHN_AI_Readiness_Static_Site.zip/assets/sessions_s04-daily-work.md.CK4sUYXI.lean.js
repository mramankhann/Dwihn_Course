import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S4 · AI in Your Daily DWIHN Work","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s04-daily-work.md","filePath":"sessions/s04-daily-work.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s04-daily-work.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 28)
  ])]);
}
const s04DailyWork = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s04DailyWork as default
};
