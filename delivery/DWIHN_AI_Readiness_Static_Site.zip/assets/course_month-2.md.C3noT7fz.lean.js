import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Month 2 · Advanced AI & Lumenore Mastery","description":"","frontmatter":{},"headers":[],"relativePath":"course/month-2.md","filePath":"course/month-2.md","lastUpdated":null}');
const _sfc_main = { name: "course/month-2.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 14)
  ])]);
}
const month2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  month2 as default
};
