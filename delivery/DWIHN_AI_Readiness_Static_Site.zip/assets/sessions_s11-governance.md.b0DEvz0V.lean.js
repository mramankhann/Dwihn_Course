import { _ as _imports_0 } from "./chunks/incident-flow.BY9dCdgV.js";
import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S11 · AI Governance & Incident Handling","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s11-governance.md","filePath":"sessions/s11-governance.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s11-governance.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 30)
  ])]);
}
const s11Governance = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s11Governance as default
};
