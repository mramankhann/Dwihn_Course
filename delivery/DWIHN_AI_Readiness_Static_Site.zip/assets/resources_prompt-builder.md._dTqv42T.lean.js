import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Five-part prompt builder","description":"","frontmatter":{},"headers":[],"relativePath":"resources/prompt-builder.md","filePath":"resources/prompt-builder.md","lastUpdated":null}');
const _sfc_main = { name: "resources/prompt-builder.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 10)
  ])]);
}
const promptBuilder = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  promptBuilder as default
};
