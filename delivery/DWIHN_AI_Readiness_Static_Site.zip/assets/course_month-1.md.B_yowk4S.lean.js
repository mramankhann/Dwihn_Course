import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Month 1 · AI Foundations & Safe Usage","description":"","frontmatter":{},"headers":[],"relativePath":"course/month-1.md","filePath":"course/month-1.md","lastUpdated":null}');
const _sfc_main = { name: "course/month-1.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 14)
  ])]);
}
const month1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  month1 as default
};
