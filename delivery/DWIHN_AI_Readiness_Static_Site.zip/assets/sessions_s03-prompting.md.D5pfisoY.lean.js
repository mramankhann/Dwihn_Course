import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S3 · Prompting Skills for DWIHN Roles","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s03-prompting.md","filePath":"sessions/s03-prompting.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s03-prompting.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 38)
  ])]);
}
const s03Prompting = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s03Prompting as default
};
