import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse(`{"title":"S1 · What AI Is — and Isn't","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s01-what-ai-is.md","filePath":"sessions/s01-what-ai-is.md","lastUpdated":null}`);
const _sfc_main = { name: "sessions/s01-what-ai-is.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 29)
  ])]);
}
const s01WhatAiIs = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s01WhatAiIs as default
};
