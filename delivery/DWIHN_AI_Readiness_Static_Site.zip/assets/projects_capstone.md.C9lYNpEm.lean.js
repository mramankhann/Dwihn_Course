import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Capstone · From safe input to accountable action","description":"","frontmatter":{},"headers":[],"relativePath":"projects/capstone.md","filePath":"projects/capstone.md","lastUpdated":null}');
const _sfc_main = { name: "projects/capstone.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 17)
  ])]);
}
const capstone = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  capstone as default
};
