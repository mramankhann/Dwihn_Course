import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Data classification desk card","description":"","frontmatter":{},"headers":[],"relativePath":"resources/data-desk-card.md","filePath":"resources/data-desk-card.md","lastUpdated":null}');
const _sfc_main = { name: "resources/data-desk-card.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 10)
  ])]);
}
const dataDeskCard = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  dataDeskCard as default
};
