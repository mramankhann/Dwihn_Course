import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse(`{"title":"","description":"","frontmatter":{"layout":"home","hero":{"name":"DWIHN AI Readiness","text":"Learn to use AI safely in real DWIHN work","tagline":"Twelve live sessions, ten modules, nine weeks. Practice with synthetic cases before using any approved workplace tool.","actions":[{"theme":"brand","text":"Start the course","link":"/course/overview"},{"theme":"alt","text":"View the roadmap","link":"/course/roadmap"}]},"features":[{"title":"Safe foundations","details":"Understand AI's strengths and limits, approved tools, HIPAA boundaries, classification, and prompting."},{"title":"Real role practice","details":"Work through care coordination, call center, program reporting, administration, compliance, and leadership cases."},{"title":"Evidence to action","details":"Ask better data questions in Lumenore, review Genesys AI signals, and make accountable decisions."},{"title":"Readiness assessment","details":"Complete checks during the course and finish with a 20-question assessment and practical case."}]},"headers":[],"relativePath":"index.md","filePath":"index.md","lastUpdated":null}`);
const _sfc_main = { name: "index.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode('<div class="warning custom-block"><p class="custom-block-title">Before live use</p><p>This training site contains <strong>synthetic examples</strong>. The proposal does not provide DWIHN&#39;s current approved-tool catalog, exact data-tier policy, incident contacts, or tenant feature configuration. Follow current DWIHN policy and your authorized access for real work.</p></div><p>The curriculum follows the DWIHN AI Training Handbook and Netlink / NetSeed 2026 proposal. Start with the <a href="/course/overview">overview</a>, then work through <a href="/course/month-1">Month 1 modules</a> and <a href="/course/month-2">Month 2 modules</a> alongside the <a href="/course/roadmap">session roadmap</a>. Instructors should review the <a href="/course/instructor-guide">delivery guide</a> and <a href="/resources/references">verification list</a> before teaching.</p>', 2)
  ])]);
}
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  index as default
};
