import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Synthetic analytics practice data","description":"","frontmatter":{},"headers":[],"relativePath":"resources/synthetic-data.md","filePath":"resources/synthetic-data.md","lastUpdated":null}');
const _sfc_main = { name: "resources/synthetic-data.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 11)
  ])]);
}
const syntheticData = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  syntheticData as default
};
