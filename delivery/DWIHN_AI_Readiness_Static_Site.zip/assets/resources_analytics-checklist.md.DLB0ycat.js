import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Analytics review card","description":"","frontmatter":{},"headers":[],"relativePath":"resources/analytics-checklist.md","filePath":"resources/analytics-checklist.md","lastUpdated":null}');
const _sfc_main = { name: "resources/analytics-checklist.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode('<h1 id="analytics-review-card" tabindex="-1">Analytics review card <a class="header-anchor" href="#analytics-review-card" aria-label="Permalink to &quot;Analytics review card&quot;">​</a></h1><p>Use this checklist before citing an AI-generated chart, Lumenore answer, alert, or board report.</p><table tabindex="0"><thead><tr><th>Check</th><th>Ask</th></tr></thead><tbody><tr><td>Decision</td><td>What decision is the analysis meant to support?</td></tr><tr><td>Definition</td><td>What exactly are the numerator, denominator, population, and exclusions?</td></tr><tr><td>Source</td><td>Which governed dataset and refresh time produced the view?</td></tr><tr><td>Period</td><td>Are dates and comparison windows aligned?</td></tr><tr><td>Filters</td><td>Which ZIP, program, service, or staff filters are active?</td></tr><tr><td>Magnitude</td><td>Is the change in counts, percent, or <strong>percentage points</strong>?</td></tr><tr><td>Stability</td><td>Is the subgroup large enough? Are small cells protected under DWIHN rules?</td></tr><tr><td>Alternatives</td><td>What else could explain the pattern? What would disprove our first guess?</td></tr><tr><td>Action</td><td>Who will do what by when, and which measure will show whether it worked?</td></tr><tr><td>Audience</td><td>May this person see the chart or export? Does the link have appropriate access?</td></tr></tbody></table><p><strong>Example:</strong> In the invented exercise, a change from 74.5% to 73.0% is a decline of 1.5 <strong>percentage points</strong>. The cause remains unknown. <a href="/resources/synthetic-data">Synthetic dataset</a> · <a href="/sessions/s05-lumenore-ask-me">S5–S7</a></p>', 4)
  ])]);
}
const analyticsChecklist = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  analyticsChecklist as default
};
