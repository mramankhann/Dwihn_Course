import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const _imports_0 = "/diagrams/safe-use.svg";
const __pageData = JSON.parse('{"title":"Course overview","description":"","frontmatter":{},"headers":[],"relativePath":"course/overview.md","filePath":"course/overview.md","lastUpdated":null}');
const _sfc_main = { name: "course/overview.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 19)
  ])]);
}
const overview = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  overview as default
};
