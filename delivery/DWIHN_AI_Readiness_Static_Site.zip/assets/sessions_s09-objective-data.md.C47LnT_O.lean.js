import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S9 · Objective Decisions with Data: A Single Source of Truth","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s09-objective-data.md","filePath":"sessions/s09-objective-data.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s09-objective-data.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 27)
  ])]);
}
const s09ObjectiveData = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s09ObjectiveData as default
};
