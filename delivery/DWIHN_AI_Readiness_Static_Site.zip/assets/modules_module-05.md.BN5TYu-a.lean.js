import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Module 5 · AI in Your Daily DWIHN Work","description":"","frontmatter":{},"headers":[],"relativePath":"modules/module-05.md","filePath":"modules/module-05.md","lastUpdated":null}');
const _sfc_main = { name: "modules/module-05.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 45)
  ])]);
}
const module05 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  module05 as default
};
