import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"Module 10 · Knowledge Assessment & Certification","description":"","frontmatter":{},"headers":[],"relativePath":"modules/module-10.md","filePath":"modules/module-10.md","lastUpdated":null}');
const _sfc_main = { name: "modules/module-10.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 45)
  ])]);
}
const module10 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  module10 as default
};
