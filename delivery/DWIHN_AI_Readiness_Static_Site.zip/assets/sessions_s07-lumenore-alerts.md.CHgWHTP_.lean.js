import { _ as _export_sfc, o as openBlock, c as createElementBlock, a2 as createStaticVNode } from "./chunks/framework.B1k-ukVh.js";
const __pageData = JSON.parse('{"title":"S7 · Lumenore Impact: Smart Alerts and Board-Ready Reports","description":"","frontmatter":{},"headers":[],"relativePath":"sessions/s07-lumenore-alerts.md","filePath":"sessions/s07-lumenore-alerts.md","lastUpdated":null}');
const _sfc_main = { name: "sessions/s07-lumenore-alerts.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 29)
  ])]);
}
const s07LumenoreAlerts = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  s07LumenoreAlerts as default
};
